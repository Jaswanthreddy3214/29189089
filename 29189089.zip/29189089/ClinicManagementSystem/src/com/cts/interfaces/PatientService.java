package com.cts.interfaces;

import com.cts.exception.PatientNotFoundException;
import com.cts.model.PatientRecord;

public interface PatientService {
	public abstract void patientRecord(PatientRecord patientRecord) throws PatientNotFoundException;
	public abstract void addPatient(PatientRecord patientRecord);
	public abstract void viewAllPatients();
	public abstract void updatePatient(PatientRecord patientRecord,int patientId) throws PatientNotFoundException;
	public abstract void deletePatient(int patientId);
}
