package com.cts.interfaces;

import com.cts.exception.AppointmentNotFoundException;
import com.cts.model.AppointmentRecord;

public interface AppointmentService {
	public abstract void appointmentRecord(AppointmentRecord appointmentRecord) throws AppointmentNotFoundException;
	public abstract void scheduleAppointment(AppointmentRecord appointmentRecord);
	public abstract void viewAllAppointments();
	public abstract void updateAppointment(AppointmentRecord appointmentRecord,int appointmentId) throws AppointmentNotFoundException;
	public abstract void cancelAppointment(int appointmentId) throws AppointmentNotFoundException;
}
