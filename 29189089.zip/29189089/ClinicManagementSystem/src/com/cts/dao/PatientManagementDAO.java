package com.cts.dao;

import java.util.Scanner;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cts.exception.PatientNotFoundException;
import com.cts.model.PatientRecord;
import com.cts.util.*;

public class PatientManagementDAO {
	
	
	public void patientRecord() throws PatientNotFoundException
	{
	    Scanner sc = new Scanner(System.in);
        System.out.println("\n--- Patient Management ---");
        System.out.println("1. Add Patient");
        System.out.println("2. View Patient");
        System.out.println("3. Update Patient");
        System.out.println("4. Delete Patient");
        System.out.print("Choose an option: \n");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
            	System.out.print("Enter name: ");
                String name = sc.next();
                System.out.print("Enter Age: ");
                String age = sc.next();
                System.out.print("Enter gender: ");
                String gender = sc.next();
                System.out.print("Enter contact info: ");
                String contactInfo = sc.next();
                
                PatientRecord patientRecord = new PatientRecord(name,age,gender,contactInfo);
                addPatient(patientRecord);
                break;
            case 2:
                viewAllPatients();
                break;
            case 3:
                System.out.print("Enter patient ID: ");
                int patientId = sc.nextInt(); 
                System.out.print("Enter new name: ");
                name = sc.next();
                System.out.print("Enter new Age: ");
                age = sc.next();
                System.out.print("Enter new gender: ");
                gender = sc.next();
                System.out.print("Enter new contact info: ");
                contactInfo = sc.next();// Capture the patient ID
                PatientRecord patientRecord1 = new PatientRecord(name,age,gender,contactInfo);
                updatePatient(patientRecord1,patientId);    // Call the updatePatient method
                break;
            case 4:
                System.out.print("Enter patient ID: ");
                patientId = sc.nextInt();        // Capture the patient ID
                deletePatient(patientId);     // Call the deletePatient method
                break;
                
            default:
                System.out.println("Invalid option.");
        }
	}
	
    //adding patient details
    public void addPatient(PatientRecord patientRecord) {
        try (Connection conn = ConnectionProvider.createConnection()) {
            
            String sql = "INSERT INTO Patient (name, age, gender, contact_info) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, patientRecord.getName());
            pstmt.setString(2, patientRecord.getAge());
            pstmt.setString(3, patientRecord.getGender());
            pstmt.setString(4, patientRecord.getContactNo());

            pstmt.executeUpdate();
            System.out.println("Patient added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding patient: " + e.getMessage());
        }
    }

    //viewing all patients
    public void viewAllPatients() {
        try (Connection conn = ConnectionProvider.createConnection()) {
            String sql = "SELECT * FROM Patient";  // Query to select all patients
            PreparedStatement pstmt = conn.prepareStatement(sql);  // Create a statement object
            ResultSet rs = pstmt.executeQuery(sql);  // Execute the query and get the result set

            System.out.println("\n--- Patient List ---");

         
            System.out.printf("%-10s %-20s %-15s %-10s %-20s%n", "Patient_ID", "Name", "age", "Gender", "Contact Info");
            System.out.println("--------------------------------------------------------------------------------------");

            boolean hasPatients = false;  // Flag to check if there are any patients in the database

            while (rs.next()) {  // Iterate over the result set
                hasPatients = true;
                int patientId = rs.getInt("patient_id");
                String name = rs.getString("name");
                String dateOfBirth = rs.getString("age");
                String gender = rs.getString("gender");
                String contactInfo = rs.getString("contact_info");

               
                System.out.printf("%-10d %-20s %-15s %-10s %-20s%n", patientId, name, dateOfBirth, gender, contactInfo);
            }

            if (!hasPatients) {
                System.out.println("No patients found.");
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving patients: " + e.getMessage());
        }
    }


    // updating patient details
    public void updatePatient(PatientRecord patientRecord,int patientId) throws PatientNotFoundException {
        try (Connection conn = ConnectionProvider.createConnection()) {
        	          

            String sql = "UPDATE Patient SET name = ?, age = ?, gender = ?, contact_info = ? WHERE patient_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, patientRecord.getName());
            pstmt.setString(2, patientRecord.getAge());
            pstmt.setString(3, patientRecord.getGender());
            pstmt.setString(4, patientRecord.getContactNo());
            pstmt.setInt(5, patientId);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Patient information updated successfully.");
            } else {
            	throw new PatientNotFoundException("Patient with ID " + patientId + " not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating patient: " + e.getMessage());
        }
    }
    
    //deleting patient details
    public void deletePatient(int patientId) {
        try (Connection conn = ConnectionProvider.createConnection()) {
            // First, check if the patient exists
            String checkSql = "SELECT * FROM Patient WHERE patient_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, patientId);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                // Patient exists, proceed with deletion
                String deleteSql = "DELETE FROM Patient WHERE patient_id = ?";
                PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
                deleteStmt.setInt(1, patientId);

                int rowsDeleted = deleteStmt.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("Patient deleted successfully.");
                } else {
                    System.out.println("Error: Could not delete patient.");
                }
            } else {
                System.out.println("Patient not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting patient: " + e.getMessage());
        }
    }
}
