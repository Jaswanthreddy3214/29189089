package com.cts.dao;

import java.sql.*;
import java.util.Scanner;

import com.cts.exception.AppointmentNotFoundException;
import com.cts.interfaces.AppointmentService;
import com.cts.model.AppointmentRecord;
import com.cts.util.*;
public class AppointmentManagementDAO implements AppointmentService{
	

	@Override
	public void appointmentRecord(AppointmentRecord appointmentRecord) throws AppointmentNotFoundException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    System.out.println("\n--- Appointment Management ---");
	    System.out.println("1. Schedule Appointment");
	    System.out.println("2. View Appointment");
	    System.out.println("3. Update Appointment");
	    System.out.println("4. Cancel Appointment");
	    System.out.print("Choose an option: ");
	    int choice = sc.nextInt();

	    switch (choice) {
	        case 1:
	        	 System.out.print("Enter patient ID: ");
	             int patientId = sc.nextInt();
	             sc.nextLine();  // consume the newline character
	             System.out.print("Enter appointment date (YYYY-MM-DD): ");
	             String appointmentDate = sc.nextLine();
	             System.out.print("Enter doctor name: ");
	             String doctorName = sc.nextLine();
	             String status = "scheduled";
	             
	            appointmentRecord = new AppointmentRecord(patientId,appointmentDate,doctorName,status);
	            scheduleAppointment(appointmentRecord);
	            break;
	            
	        case 2:
	            viewAllAppointments();
	            break;
	            
	        case 3:
	            System.out.print("Enter appointment ID: ");
	            int appointmentId = sc.nextInt();
	            sc.nextLine();
	            System.out.print("Enter new appointment date (YYYY-MM-DD): ");
	            appointmentDate = sc.nextLine();
	            System.out.print("Enter new doctor name: ");
	            doctorName = sc.nextLine();
	            System.out.print("Enter new status (scheduled/completed/cancelled): ");
	            status = sc.nextLine();
	            appointmentRecord = new AppointmentRecord(appointmentDate,doctorName,status);
	            updateAppointment(appointmentRecord ,appointmentId);
	            break;
	            
	        case 4:
	            System.out.print("Enter appointment ID: ");
	            appointmentId = sc.nextInt();
	            cancelAppointment(appointmentId);
	            break;
	            
	        default:
	            System.out.println("Invalid option.");
	    }
	}

	// scheduling the appointments

	@Override
	public void scheduleAppointment(AppointmentRecord appointmentRecord) {
		// TODO Auto-generated method stub
		try (Connection connection = ConnectionProvider.createConnection()) {
            
            String sql = "INSERT INTO Appointment (patient_id, appointment_date, doctor_name, status) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, appointmentRecord.getPatientId());
            pstmt.setString(2, appointmentRecord.getAppointmentDate());
            pstmt.setString(3, appointmentRecord.getDoctorName());
            pstmt.setString(4, appointmentRecord.getStatus());

            pstmt.executeUpdate();
            System.out.println("Appointment scheduled successfully.");
        } catch (SQLException e) {
            System.out.println("Error scheduling appointment: " + e.getMessage());
        }

	}

	//Viewing all  Appointments
	
	@Override
	public void viewAllAppointments() {
		// TODO Auto-generated method stub
		 try (Connection connection = ConnectionProvider.createConnection()) {
	            String sql = "SELECT * FROM Appointment";               // Query to select all appointments
	            PreparedStatement pstmt = connection.prepareStatement(sql);   // Create a statement object
	            ResultSet rs = pstmt.executeQuery(sql);                // Execute the query and get the result set

	            System.out.println("\n--- Appointment List ---");

	            // Print the table header
	            System.out.printf("%-15s %-15s %-20s %-20s %-15s%n", "Appointment ID", "Patient ID", "Appointment Date", "Doctor Name", "Status");
	            System.out.println("-----------------------------------------------------------------------------------------------------");

	            boolean hasAppointments = false;                     // Flag to check if there are any appointments in the database

	            while (rs.next()) {  
	                hasAppointments = true;
	                int appointmentId = rs.getInt("appointment_id");
	                int patientId = rs.getInt("patient_id");
	                String appointmentDate = rs.getString("appointment_date");
	                String doctorName = rs.getString("doctor_name");
	                String status = rs.getString("status");

	               
	                System.out.printf("%-15d %-15d %-20s %-20s %-15s%n", appointmentId, patientId, appointmentDate, doctorName, status);
	            }

	            if (!hasAppointments) {
	                System.out.println("No appointments found.");
	            }

	        } catch (SQLException e) {
	            System.out.println("Error retrieving appointments: " + e.getMessage());
	        }

	}

	//Updating the appointment schedule
	@Override
	public void updateAppointment(AppointmentRecord appointmentRecord, int appointmentId)  throws AppointmentNotFoundException {
		// TODO Auto-generated method stub
		
		try (Connection conn = ConnectionProvider.createConnection()) {
			   
            String sql = "UPDATE Appointment SET appointment_date = ?, doctor_name = ?, status = ? WHERE appointment_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, appointmentRecord.getAppointmentDate());
            pstmt.setString(2, appointmentRecord.getDoctorName());
            pstmt.setString(3, appointmentRecord.getStatus());
            pstmt.setInt(4, appointmentId);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Appointment updated successfully.");
            } else {
            	throw new AppointmentNotFoundException("Appointment with ID " + appointmentId + " not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating appointment: " + e.getMessage());
        }

	}

	
	//Cancelling Appointment
	
	@Override
	public void cancelAppointment(int appointmentId) throws AppointmentNotFoundException {
		// TODO Auto-generated method stub
		 try (Connection conn = ConnectionProvider.createConnection()) {
	            String sql = "UPDATE Appointment SET status = 'cancelled' WHERE appointment_id = ?";
	            PreparedStatement pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, appointmentId);

	            int rowsUpdated = pstmt.executeUpdate();
	            if (rowsUpdated > 0) {
	                System.out.println("Appointment canceled successfully.");
	            } else {
	            	throw new AppointmentNotFoundException("Appointment with ID " + appointmentId + " not found.");
	            }
	        } catch (SQLException e) {
	            System.out.println("Error canceling appointment: " + e.getMessage());
	        }
	    }
}
