package com.cts.util;

import java.sql.Connection;
import java.sql.DriverManager;


public class ConnectionProvider {
	
	static Connection con;
	
	private static final String DRIVER_PATH = "com.mysql.cj.jdbc.Driver";
	private static final String DRIVER_URL = "jdbc:mysql://localhost:3306/clinic_db";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "Password";
	
	public static Connection createConnection() {
			
			//steps of creating Database connection...
			try {
			//1. load the driver
			Class.forName(DRIVER_PATH);
			
			//2. Create the connection...
			con = DriverManager.getConnection(DRIVER_URL,USERNAME,PASSWORD);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//return the connection
		return con;
		
	}
}

