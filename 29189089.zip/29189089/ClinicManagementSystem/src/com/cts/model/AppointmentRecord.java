package com.cts.model;

public class AppointmentRecord {
	
	private int patientId;
	private String appointmentDate;
	private String doctorName;
	private String status;
	
	
	//getters and setters of Appointment Record
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	
	//parameterised constructor
	public AppointmentRecord(int patientId, String appointmentDate, String doctorName, String status) {
		super();
		this.patientId = patientId;
		this.appointmentDate = appointmentDate;
		this.doctorName = doctorName;
		this.status = status;
	}
	
	//parameterised constructor
	public AppointmentRecord(String appointmentDate, String doctorName, String status) {
		super();
		this.appointmentDate = appointmentDate;
		this.doctorName = doctorName;
		this.status = status;
	}
}
	
	

