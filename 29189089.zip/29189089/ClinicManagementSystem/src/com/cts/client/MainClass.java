package com.cts.client;

import java.util.Scanner;

import com.cts.dao.*;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PatientManagementDAO patientManagement = new PatientManagementDAO();
        AppointmentManagementDAO appointmentManagement = new AppointmentManagementDAO();
        MedicalRecordManagementDAO medicalRecordManagement = new MedicalRecordManagementDAO();
		
		try (Scanner scanner = new Scanner(System.in)) {
			while(true)
			{
				System.out.println("\n--- Clinic Management System ---");
			    System.out.println("1. Patient Management");
			    System.out.println("2. Appointment Management");
			    System.out.println("3. Medical Record Management");
			    System.out.println("4. Exit");
			    
			    System.out.print("Choose an option: \n");
			    int record = scanner.nextInt();

			    switch (record) {
			        case 1:
			            patientManagement.patientRecord();
			            break;
			        case 2:
			            appointmentManagement.appointmentRecord();
			            break;
			        case 3:
			            medicalRecordManagement.medicalRecord();
			            break;
			        case 4:
			            System.out.println("Exiting the system.");
			            System.exit(0);
			        default:
			            System.out.println("Invalid option. Please try again.");
			            }
			    }
			}
		catch(Exception e){
			System.out.println(e);
			}
		}
}