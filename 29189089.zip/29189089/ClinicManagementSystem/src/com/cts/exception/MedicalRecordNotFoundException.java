package com.cts.exception;

public class MedicalRecordNotFoundException extends Exception{
	public MedicalRecordNotFoundException(String message)
	{
		super(message);
	}
}
